<?= 
 include '../index/usuariov.php';
        ?>
        <!DOCTYPE html>
<html>
<head>
    <title>Visor de PDF</title>
    <style>
       object{
              margin-left: 170px;}
       </style>
</head>
<body>
    <h1>Visor de PDF</h1>
    <object data=" ../el_mito_de_sisifo.pdf" type="application/pdf" width="90%" height="800">
        <p>No es posible mostrar el PDF. <a href="el_mito_de_sisifo.pdf">Descargar PDF</a></p>
    </object>

    </object>
</body>
</html>