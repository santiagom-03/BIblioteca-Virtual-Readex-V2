<?php
$host = "localhost";
$db = "test";
$user = "root";
$passwd = "";
$password = "";